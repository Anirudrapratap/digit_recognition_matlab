⏬******************Digit Recognition Using Neural Network******************⏬

prerequisits: Matlab basic library

step1:Download and extract the mnist_train to the main directory.

step2: Run the train.m file to extract images from 0 to 9 in folder(this will generate jpg images) .

step3:Run digitrecog.m to train the newral network(it contains cnn and layers) and will show the graph with accuracy.

step4:Run the testing.m file,the user will be prompted to select imagefile and a wimdow will show the recognised digit as output.

U can also download test images or create ur own in microsoft paint or any application.(make sure the image should be 28 x 28).
